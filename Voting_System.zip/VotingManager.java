import java.util.Scanner;
public class VotingManager {
    private static final String NAWKA = "NAWKA";
    private static final String DHANER_SHISH = "DHANER SHISH";

    private VotingProcessor votingProcessor;

    public VotingManager() 
    {
        votingProcessor = new VotingProcessor();
    }

    public void startVoting() 
    {
        votingProcessor.generateKeys();
    
        Scanner scanner = new Scanner(System.in);
    
        System.out.println("===> Main Menu <===");
        System.out.println("1. Log in");
        System.out.println("2. Show Results");
        System.out.print("Enter your choice: ");
        int option = scanner.nextInt();
    
        switch (option) 
        {
            case 1:
                votingProcessor.userLogin(scanner);
                break;
            case 2:
                votingProcessor.displayTotalVotes(); // Add this line to display results
                break;
            default:
                System.out.println("Invalid choice.");
        }
    
        scanner.close();
    }    
}
