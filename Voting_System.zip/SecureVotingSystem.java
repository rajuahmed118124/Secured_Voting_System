import java.util.Scanner;

public class SecureVotingSystem {
    public static void main(String[] args) 
    {
        VotingManager votingManager = new VotingManager();
        votingManager.startVoting();
    }
}
